package com.woodchuck.gateway_servlet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayServletApplicationTests {

	@Test
	void contextLoads() {
	}

}
